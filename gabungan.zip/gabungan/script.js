// Navbar background color change on scroll
window.onscroll = function() {
    const navbar = document.getElementById('navbar');
    if (window.scrollY > 100) {
        navbar.style.backgroundColor = '#000';
    } else {
        navbar.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
    }
};

// Mouse hover effect for 3D text in hero section
const heroText = document.querySelector('.hero h1');
document.addEventListener('mousemove', (e) => {
    const x = (window.innerWidth - e.pageX) / 30;
    const y = (window.innerHeight - e.pageY) / 30;
    heroText.style.transform = `rotateX(${y}deg) rotateY(${x}deg)`;
});
